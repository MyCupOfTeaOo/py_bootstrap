from .config import config, get_app_homepage
__all__ = ('config', 'get_app_homepage')
