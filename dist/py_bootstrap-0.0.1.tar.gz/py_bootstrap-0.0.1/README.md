# 底层封装(redis)
  `pip install pytest`
  `pip install -r requirements.txt` 安装依赖
  `pytest` 运行测试用例